/*
 * Autor: Jorge Castro ; Fausto Males
 * Software: SUPERCINES
 * Fecha: 
 * Hora: 
 * Version: 1.0.0
 */

package Principales;

public class txtButacas {

    public String A1;
    public String A2;
    public String A3;
    public String A4;
    public String A5;
    public String A6;
    public String A7;
    public String A8;
    public String A9;
    public String A10;
    public String A11;
    public String A12;
    public String A13;
    public String A14;
    public String A15;
    public String A16;
    public String A17;
    public String A18;
    public String A19;
    public String A20;
    public String A21;
    public String A22;
    public String A23;
    public String A24;
    public String A25;
    public String A26;
    public String A27;
    public String A28;
    public String A29;
    public String A30;

    txtButacas(String asiento1, String asiento2, String asiento3, String asiento4, String asiento5, String asiento6, String asiento7, String asiento8, String asiento9, String asiento10, String asiento11, String asiento12, String asiento13, String asiento14, String asiento15, String asiento16, String asiento17, String asiento18, String asiento19, String asiento20, String asiento21, String asiento22, String asiento23, String asiento24, String asiento25, String asiento26, String asiento27, String asiento28, String asiento29, String asiento30) {
       
        this.A1 = asiento1;
        this.A2 = asiento2;
        this.A3 = asiento3;
        this.A4 = asiento4;
        this.A5 = asiento5;
        this.A6 = asiento6;
        this.A7 = asiento7;
        this.A8 = asiento8;
        this.A9 = asiento9;
        this.A10 = asiento10;
        this.A11 = asiento11;
        this.A12 = asiento12;
        this.A13 = asiento13;
        this.A14 = asiento14;
        this.A15 = asiento15;
        this.A16 = asiento16;
        this.A17 = asiento17;
        this.A18 = asiento18;
        this.A19 = asiento19;
        this.A20 = asiento20;
        this.A21 = asiento21;
        this.A22 = asiento22;
        this.A23 = asiento23;
        this.A24 = asiento24;
        this.A25 = asiento25;
        this.A26 = asiento26;
        this.A27 = asiento27;
        this.A28 = asiento28;
        this.A29 = asiento29;
        this.A30 = asiento30;

    }
}